from django.contrib import admin
from core.models import Spotteds

# Register your models here.

admin.site.register(Spotteds)
